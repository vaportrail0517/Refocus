//
//  iOSApp.swift
//  iOS
//
//  Created by Takechiyo Sakazaki on 2025/12/19.
//

import SwiftUI

@main
struct iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
